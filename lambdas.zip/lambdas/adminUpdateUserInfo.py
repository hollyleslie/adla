import json
import boto3

def lambda_handler(event, context):

    qsParams = event['queryStringParameters']
    print(qsParams)
    user_id = qsParams['user_id']
    print(event)
    event = json.loads(event['body'])
    print(event)

    print('updating entry with:', event)

    ddb = boto3.resource('dynamodb')
    table = ddb.Table('Users')
    body = table.get_item(
        Key={'user_sub': user_id}
    )['Item']
    print('original entry:', body)
    body.update(event)
    print('final entry:', body)
    table.put_item(Item=body)

    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!'),
        'headers': {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": True,
            "Access-Control-Allow-Methods": "*"
        }
    }

