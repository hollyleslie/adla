import json
import boto3
from boto3.dynamodb.conditions import Key, Attr
import random

def lambda_handler(event, context):

    # print('initial event:', event)
    # user_id = event['context']['sub']
    # print('user id:', user_id)
    # event = event['body-json']
    # print(event)
    
    # # GET USER DETAILS
    # ddb = boto3.resource('dynamodb')
    # table = ddb.Table('Users')
    # user = table.get_item(Key={'user_sub': user_id})['Item']
    # gender = user['gender'].lower()
    # print(gender)
    # if gender == 'other':
    #     gender = ''
    
    
    # GET RECOMMENDATION DETAILS
    pathParams = event['queryStringParameters']
    print('path parameters', pathParams)
    if 'gender' in pathParams.keys():
        gender = pathParams['gender']
        if gender == 'other':
            gender = ''
    else:
        gender = ''
    print('gender:', gender)
    
    # GET PHOTOS
    s3 = boto3.client('s3')
    l = s3.list_objects(Bucket='adla-data', Prefix=f'public/swipe_images/{gender}')
    l = l['Contents']
    l = [item['Key'] for item in l]
    l = ['https://adla-data.s3-eu-west-1.amazonaws.com/' + key for key in l]

    sample = []
    while len(sample) < 3:
        id = random.choice(l)
        sample.append(id)
    
    print('sample:', sample)
    l = sample
    print(type(l))
    print(l)
    

    return {
        'statusCode': 200,
        'body': json.dumps(l),
        'headers': {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": True,
            "Access-Control-Allow-Methods": "*"
        }
    }

