import json
import boto3
import ast

def lambda_handler(event, context):

    print('initial event:', event)
    user_id = event['context']['sub']
    print('user_id:', user_id)
    event = event['body-json']
    print(event)
    
    ddb = boto3.resource('dynamodb')
    table = ddb.Table('Stylists')
    user_info = table.get_item(Key={'stylist_id': user_id})['Item']
    print(user_info)
    user_info.update(event)
    print(user_info)
    table.put_item(Item=user_info)
    return {
        "statusCode": 200,
        "body":  json.dumps('Success!'),
        "headers": { 
            "Access-Control-Allow-Origin": "*"
        }
    }
