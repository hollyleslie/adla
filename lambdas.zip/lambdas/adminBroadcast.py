import json
import boto3
import uuid
from decimal import Decimal
import time

def lambda_handler(event, context):

    ddb = boto3.resource('dynamodb')
    msg_table = ddb.Table('StylistMessageBuffer')
    msg = {
        'content': event['msg'],
        'type': 'text',
        'send_time': Decimal(time.time())  # add index to ensure messages can be ordered
    }
    print('sending:', event['msg'])

    if event['group'] == 'stylists':
        stylists = ddb.Table('Stylists').scan()['Items']
        #stylists = [stylist for stylist in stylists if stylist['name'] in ['Harry', 'haron.stylist']]
        for stylist in stylists:
            try:
                contact_method = stylist['contact_method']
                target = stylist[contact_method]
                msg.update({
                    'target': target,
                    'contact_method': contact_method,
                    'message_id': str(uuid.uuid4()),
                    'stylist_id': stylist['stylist_id'],
                    'stylist': True,
                    'category': 'general'
                })
                msg_table.put_item(Item=msg)
            except:
                print('failed for stylist:', stylist['name'])

    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }

