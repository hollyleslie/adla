import json
import boto3
from boto3.dynamodb.conditions import Key
import decimal

class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            if abs(o) % 1 > 0:
                return float(o)
            else:
                return int(o)
        return super(DecimalEncoder, self).default(o)

def lambda_handler(event, context):
    print('initial event:', event)
    stylist_id = event['context']['sub']
    print('user_id:', stylist_id)
    event = event['body-json']
    print(event)
    ddb = boto3.resource('dynamodb')
    rec_table = ddb.Table('Recommendations')
    recs = rec_table.query(
        KeyConditionExpression=Key('recommended_by').eq(stylist_id),
        IndexName='recommended_by-index'
    )['Items']
    return {
        'statusCode': 200,
        'body': json.dumps(recs, cls=DecimalEncoder)
    }

