import json
import boto3
from boto3.dynamodb.conditions import Key


def lambda_handler(event, context):
    print('INITIAL EVENT:', event)
    pathParams = event['queryStringParameters']
    user_id = pathParams['user_id']
    
    ddb = boto3.resource('dynamodb')
    req_table = ddb.Table('Requests')
    key = {
        'IndexName': 'user_id-recommendation_id-index',
        'KeyConditionExpression': Key('user_id').eq(user_id)
    }
    reqs = req_table.query(**key)['Items']
    
    if len(reqs) == 0:
        reqs = [
            'cute outfits',
            'summer wear'
        ]

    print('REQUESTS:', reqs)

    return {
        'statusCode': 200,
        'body': json.dumps(reqs),
        "headers": { 
            "Access-Control-Allow-Origin": "*" 
        }
    }

