import json
import boto3
import heapq
import pickle

def lambda_handler(event, context):
    print('INITIAL EVENT:', event)
    user_id = event
    
    # ddb = boto3.resource('dynamodb')
    # user_table = ddb.Table('Users')
    # user = user_table.get_item(Key={'user_sub': event})['Item']
    
    # if 'priority' not in user.keys():
    #     user['priority'] = 0
    
    # user['priority'] += 100
    
    # user_table.put(Item=user)
    # UPDATE PRIORITY QUEUE
    s3 = boto3.resource('s3')                               # get s3 resource
    obj = s3.Object('adla-data', 'jobs.pickle')               # get jobs
    priorities = obj.get()['Body'].read()                   # decode to string
    priorities = pickle.loads(priorities)                     # load to object
    entry = priorities['entry_finder'][user_id]             # get users current entry
    priority, _user_id, user = entry                        # unpack current entry
    priority += 100                                         # boost priority
    print('users new priority:', priority)
    new_entry = (priority, user_id, user)                   # update entry
    heapq.heappush(priorities['priority_queue'], new_entry) # heap push new entry
    priorities['priority_queue'].remove(entry)              # remove old entry
    priorities['entry_finder'][user_id] = new_entry         # update entry finder
    obj.put(Body=pickle.dumps(priorities))                                # save updated jobs

    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }

