import json
import boto3
from boto3.dynamodb.conditions import Key, Attr
import decimal

class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            if o % 1 > 0:
                return float(o)
            else:
                return int(o)
        return super(DecimalEncoder, self).default(o)

def lambda_handler(event, context):
    
    print('initial event:', event)
    pathParams = event['queryStringParameters']
    user_id = pathParams['user_id']
    #event = json.dumps(event['body'])

    ddb = boto3.resource('dynamodb')
    
    # user_table = ddb.Table('Users')
    # user = user_table.get_item(Key={'user_sub': user_id})['Item']
    
    # print('USER:', user)
    
    # brand_list = []
    # if 'brands' in user.keys():
    #     brand_list = user['brands']
    #     print('BRAND LIST:', brand_list)
    # if 'styles' in user.keys():
    
    #     style_list = user['styles']
    #event = json.loads(event)
    body = event['body']
    body = json.loads(body)
    print(body)
    print(type(body))
    brand_list = body['brands']
    product_table = ddb.Table('Products')
    fe = Attr('brand').is_in(brand_list) #& Attr('style').is_in(stylelist)
    #eav = { ":brandList":["Cliff"]} #, ":styleList":["casual"] }
    #products = table.scan(FilterExpression=fe,ExpressionAttributeValues=eav)['Items']
    products = product_table.scan(FilterExpression=fe)['Items']
    print(products)

    return {
        'statusCode': 200,
        'body': json.dumps(products, cls=DecimalEncoder),    
        'headers': {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": True,
            "Access-Control-Allow-Methods": "*"
        }
    }

