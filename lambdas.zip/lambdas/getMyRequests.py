import json
import boto3
from boto3.dynamodb.conditions import Key


def lambda_handler(event, context):

    s3 = boto3.resource('s3')
    my_bucket = s3.Bucket('adla-data')
    
    userSub = event['context']['sub']
    userSub = 'bd86306c-3993-4ecf-a92b-dbfcb313d44a'
    
    #  print('user sub', userSub)
    
    requests = [ob_sum.key for ob_sum in my_bucket.objects.filter(Prefix=f'users/{userSub}/requests')]
    requests = [s3.Object('adla-data', file).get()['Body'].read().decode('utf-8') for file in requests]
    requests = [json.loads(req) for req in requests]
    
    ddb = boto3.resource('dynamodb')
    table = ddb.Table('Requests')
    requests = table.query(
        IndexName='userSub-index',
        KeyConditionExpression=Key('userSub').eq(userSub)
    )['Items']
    
    print('my requests:', requests)
    

    #requests = [d for d in requests]

    return {
        'statusCode': 200,
        'body': json.dumps(requests),
        "headers": { 
            "Access-Control-Allow-Origin": "*" ,
            "Access-Control-Allow-Credentials": True
        }
    }
