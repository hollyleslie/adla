import json
import boto3
import base64
import uuid

def lambda_handler(event, context):
    
    print('INITIAL EVENT:', event)
    qparams = event['queryStringParameters']
    req_id = qparams['req_id']
    
    imgs = event['imgs']
    
    for img in imgs:
        img_id = str(uuid.uuid4())
        
        s3 = boto3.resource('s3')
        object = s3.Object('adla-data', f'formatted_recommendations/{req_id}/{img_id}')
        object.put(Body=base64.b64decode(img))

    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }

