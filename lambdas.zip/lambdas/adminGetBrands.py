import json
import boto3
from time import time
from decimal import Decimal

def lambda_handler(event, context):
    
    ddb = boto3.resource('dynamodb')
    table = ddb.Table('Brands')
    
    brands = table.scan()['Items']
    
    return {
        'statusCode': 200,
        'body': json.dumps(brands)
    }

