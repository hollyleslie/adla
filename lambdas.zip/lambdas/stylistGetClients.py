import json
import boto3
import datetime

def lambda_handler(event, context):
    
    stylist_id = event['context']['sub']
    print('stylist_id:', stylist_id)
    event = event['body-json']
    print('event:', event)

    ddb = boto3.resource('dynamodb')
    stylist_table = ddb.Table('Stylists')
    user_table = ddb.Table('Users')
    
    stylist = stylist_table.get_item(Key={'stylist_id': stylist_id})['Item']
    client_ids = stylist['clients']
    print(client_ids)
    
    clients = []
    for client_id in client_ids:
        print('getting client:', client_id)
        client = user_table.get_item(Key={'user_sub': client_id})['Item']
        
        if 'last_served' in list(client.keys()):
            last_served = datetime.datetime.strptime(client['last_served'] , '%Y-%m-%d')
            now = datetime.datetime.now()
            print(f'last served:' + str(last_served))
            diff = now - last_served
            days = diff.days
            print(f'\tlast served {days} days ago')
            if days == 0:
                print('\tuser served less than 24 hrs ago')
                continue

        clients.append(client)
    
    for client in clients:
        client.pop('password')

    return {
        'statusCode': 200,
        'body': json.dumps(clients)
    }

