import json
import boto3
from boto3.dynamodb.conditions import Key
import decimal

class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            if o % 1 > 0:
                return float(o)
            else:
                return int(o)
        return super(DecimalEncoder, self).default(o)

def lambda_handler(event, context):
    print('INITIAL EVENT:', event)
    
    user_id = event['context']['sub']
    print('Sub:', user_id)
    
    # get RECOMMENDATION TO DDB
    ddb = boto3.resource('dynamodb')
    table = ddb.Table('Recommendations')
    recs = table.query(
        KeyConditionExpression=Key('user_id').eq(user_id)
    )['Items']
    
    recs = [rec for rec in recs if rec['status'] != 'not yet recommended']

    print(recs)
   
    return {
        'statusCode': 200,
        'body': json.dumps(recs, cls=DecimalEncoder),
        "headers": { 
            "Access-Control-Allow-Origin": "*" ,
            "Access-Control-Allow-Credentials": True
        }
    }
    
    

