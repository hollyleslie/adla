import json
import boto3
from boto3.dynamodb.conditions import Key, Attr

def lambda_handler(event, context):
    print('searching not by user id')
    print('initial event:', event)

    ddb = boto3.resource('dynamodb')
    table = ddb.Table('Users')
    result = table.query(
        KeyConditionExpression=Key('instagram').eq(event['search']),
        IndexName="instagram-index"
    )['Items']
    
    print(result)
    
    return {
        "statusCode": 200,
        "body":  json.dumps(result),
        "headers": { 
            "Access-Control-Allow-Origin": "*" ,
            "Access-Control-Allow-Credentials": True
        }
    }
        

