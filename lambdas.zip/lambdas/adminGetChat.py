import json
import boto3

def lambda_handler(event, context):
    
    pathParams = event['queryStringParameters']
    print('path parameters', pathParams)
    user_id = pathParams['user_id']
    
    s3 = boto3.resource('s3')
    obj = s3.Object(bucket_name='adla-data', key=f'users/{user_id}/chat.json')
    obj = obj.get()['Body'].read().decode('utf-8')
    obj = json.loads(obj)
    print(type(obj))
    print('CHAT:', obj)

    return {
        'statusCode': 200,
        'body': json.dumps(obj),
        # "headers": { 
        #     "Access-Control-Allow-Origin": "*" ,
        #     "Access-Control-Allow-Credentials": True
        # }
    }

