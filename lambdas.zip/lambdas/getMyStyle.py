import json
import boto3

def lambda_handler(event, context):

    print('og event:', event)
    
    userSub = event['context']['sub']
    print('Sub:', userSub)

    ddb = boto3.resource('dynamodb')    
    table = ddb.Table('Style')
    try:
        item = table.get_item(
            Key={
                'userSub': userSub
            }
        )
        item = item['Item']         # error throws if no item returned (no Item key)
    except Exception as e:
        print('Error should be no key found:', e)
        item = None
    print('Item got from database:', item)

    return {
        'statusCode': 200,
        'body': json.dumps(item),
        "headers": { 
            "Access-Control-Allow-Origin": "*" ,
            "Access-Control-Allow-Credentials": True
        }
        
    }

