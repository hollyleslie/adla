import json
import boto3
import uuid
import time
import datetime
from decimal import Decimal
from boto3.dynamodb.conditions import Key
from math import ceil
import pickle
import heapq

def lambda_handler(event, context):

    print('initial event:', event)
    
    ts = time.time()
    timestamp = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')

    # GET RECOMMENDATION DETAILS
    pathParams = event['queryStringParameters']
    print('path parameters', pathParams)
    
    if pathParams is not None:  # in cases where all info is in the event
        user_id = pathParams['sub']     # should always have sub if has any
        print('user id:', user_id)
        if 'req_id' in pathParams:  # IF THIS CAME FROM A REQUEST 
            req_id = pathParams['req_id']
        else:   # OTHERWISE IT MUST BE A NON-SPECIFIC RECOMMENDATION
            req_id = None
 
    initial_event = event
 
    event = json.loads(event['body'])
    print('EVENT:', event)
    ddb = boto3.resource('dynamodb')
    table = ddb.Table('Recommendations')
    action = event.pop('action')
    print('action:', action)
    
    if action == 'prepare to recommend':
        # POST RECOMMENDATION TO DDB
        event.update({
            'user_id': user_id,
            'recommendation_id': str(uuid.uuid4()),
            'request_id': req_id,
            'timestamp': timestamp,
            'status': 'not yet recommended'
        })
    
        # IF NO PRODUCT ID GIVEN (INPUT MANUALLY FROM USER NOT TAKEN FROM PRODUCTS DB)    
        if 'product_id' not in event.keys():
            event.update({'product_id': str(uuid.uuid4())})
    
        print('adding recommendation to DB:', event)
        table.put_item(Item=event)
        
    elif action == 'recommend': # TAKES A LIST OF RECS IN 
        # idx = 1    # initialise index of this rec for this week
        
        # # CALCULATE THE INDEX OF THIS ITEM (HOW MANY RECS IN REC DB FROM THIS WK)
        # now = datetime.datetime.now()
        # tt = now.timetuple()
        # l = [i for i in tt]
        # h, m, s, d = l[3:7]
        # l = l[3:7]
        # sec_map = [60*60, 60, 1, 24*60*60]
        # since_mon = sum([sec_map[i] * l[i] for i in range(len(l))])
        # print('seconds since monday:', since_mon)
        # mon_ts = time.time() - since_mon        # timestamp for start of wk (mon)
        # recs = table.query(KeyConditionExpression=Key('user_id').eq(user_id))['Items']
        # print('all recs:', recs)
        # recs = [rec for rec in recs if rec['status'] != 'not yet recommended']
        # pattern = '%Y-%m-%d %H:%M:%S'
        # print(recs)
        # print('adding to index:', len(tuple(rec for rec in recs if time.mktime(time.strptime(recs[0]['timestamp'], pattern)) > mon_ts)))
        # idx += len(tuple(rec for rec in recs if time.mktime(time.strptime(recs[0]['timestamp'], pattern)) > mon_ts))
        # print(f'We are currently {d} days, {h} hours, {m} mins and {s} seconds into the week!')
        
        for rec in event['recs']:
            # UPDATE RECOMMENDATION STATUS IN DB
            print(rec['price'])
            print(int(rec['price']))
            print(int(rec['price']) + 10)
            
            price = rec['price']
            final_price = int(price)
            
            if final_price >= 100:
                final_price *= 1.1 
            final_price = int(final_price)
            final_price += 10 
            
            user_table = ddb.Table('Users')
            user = user_table.get_item(Key={'user_sub': rec['user_id']})['Item']
            name = user['name']
            
            rec.update({
                'status': 'recommended',
                'idx': int(time.time()),
                'final_price': final_price,
                'timestamp': timestamp,
                'recommended_by': initial_event['requestContext']['authorizer']['claims']['sub'],
                'name': name
            })
            if 'recommendation_id' not in rec.keys():
                rec.update({'recommendation_id': str(uuid.uuid4())})
            print('sending recommendation:', rec)
            table.put_item(Item=rec)
            
            rec_buffer = ddb.Table('RecommendationBuffer')
            print('PUTTING REC INTO RECOMMENDATION BUFFER:', rec)
            rec_buffer.put_item(Item=rec)
            
            # ADJUST PRIORITY
            # increase priority if they are closer to getting recommendations
            num_left = len(rec_buffer.query(KeyConditionExpression=Key('user_id').eq(rec['user_id']))['Items']) % 5
            print('# recs needed to send recommendation (until 5 recs reached', num_left)
            
            s3 = boto3.resource('s3')                               # get s3 resource
            obj = s3.Object('adla-data', 'jobs.pickle')               # get jobs
            priorities = obj.get()['Body'].read()                   # decode to string
            priorities = pickle.loads(priorities)                     # load to object
            entry = priorities['entry_finder'][user_id]             # get users current entry
            priority, _user_id, _obj = entry                        # unpack current entry
            print('adding to priority', 20*num_left)
            priority += 40 * num_left                                          # boost priority
            if user['location'] not in ['London', 'San Francisco/Bay Area']:
                print('user not in valid service ')
                priority = 0
            if num_left == 0:
                priority = 0
            print('users new priority:', priority)
            new_entry = (priority, user_id, user)                   # update entry
            heapq.heappush(priorities['priority_queue'], new_entry) # heap push new entry
            priorities['priority_queue'].remove(entry)              # remove old entry
            priorities['entry_finder'][user_id] = new_entry         # update entry finder
            obj.put(Body=pickle.dumps(priorities))                                # save updated jobs
          
            
            # # PUSH RECOMMENDATION TO MESSAGE BUFFER
            # msg_table = ddb.Table('MessageBuffer')
            # request_message = [
            #     {'content': f'{idx}. Price: {rec["final_price"]}', 'media_url': rec['img_urls'][0], 'type': 'file'}
            # ]
            # with msg_table.batch_writer() as msgbatch:
            #     for msg in request_message:
            #         msg.update({
            #             'message_id': str(uuid.uuid4()),
            #             'send_time': Decimal(time.time()),
            #             'user_id': user_id,
            #             'phone_number': 16507094150#number
            #         })
            #         print(msg['send_time'])
            #         print('adding this msg to message buffer db:', msg)
            #         msgbatch.put_item(Item=msg) 
                    
            #idx += 1    # increment recommendation index for this week
                
    elif action == 'remove':
        print('removing recommendation')
        
    elif action == 'reject':
        print('rejecting recommendation')
        event.update({"status": "rejected"})
        print(event)
        table.put_item(Item=event)
        
    elif action == 'unreject':
        print('unrejecting recommendation')
        event.update({'status': 'not yet recommended'})
        table.put_item(Item=event)
        
    elif action == 'needs ordering':
        
        user_table = ddb.Table('Users')
        user = user_table.get_item(Key={'user_sub': event['user_id']})['Item']
        print(user)
        print(user['name'])
        # MARK AS TEST 
        if 'test' in user['name']:
            event.update({'test': True})
        # # ADD SIZE AND INSTAGRAM TO ORDER
        event.update({'instagram': user['instagram']})
        if 'size' in user.keys():
            event.update({'size': user['size']})
        print('item needs ordering now!')
        assert event['status'] == 'recommended'     # prevent double orders (if this code were run after item had been added to orders and then status was already 'ordered', the product would be reset to 'needs ordering')
        event.update({'status': 'needs ordering'})
        print(event)
        event = json.loads(json.dumps(event), parse_float=Decimal)
        table.put_item(Item=event)
        orders_table = ddb.Table('Orders')
        orders_table.put_item(Item=event)
        
        stylist_table = ddb.Table('Stylists')
        stylist_message_table = ddb.Table('StylistMessageBuffer')
        
        stylist_details = stylist_table.get_item(Key={'stylist_id':event['recommended_by']})['Item']
        
        body = {
            'message_id':str(uuid.uuid4()),
            'contact_method':stylist_details['contact_method'],
            'target':stylist_details[stylist_details['contact_method']],
            'send_time':Decimal(ts),
            'type':'text',
            'stylist_id':event['recommended_by'],
            'content':'Congratst! A user just selected one of your items to try on at home!',
            'category':'item trial'
        }
        stylist_message_table.put_item(Item=body)
            
    
    elif action == 'ordered':
        print('item ordered')
        assert event['status'] == 'needs ordering'
        event.update({'status': action})
        print(event)
        table.put_item(Item=event)
        orders_table = ddb.Table('Orders')
        orders_table.put_item(Item=event)

    elif action == 'arrived':
        print('item arrived')
        assert event['status'] == 'ordered'
        event.update({'status': action})
        print(event)
        table.put_item(Item=event)
        orders_table = ddb.Table('Orders')
        orders_table.put_item(Item=event)
        
    elif action == 'needs delivering':
        print('item needs delivering')
        assert event['status'] == 'arrived'
        event.update({'status': action})
        print(event)
        table.put_item(Item=event)
        orders_table = ddb.Table('Orders')
        orders_table.put_item(Item=event)
        
    elif action == 'delivered':
        print('item delivered')
        assert event['status'] == 'arrived'
        event.update({'status': action})
        print(event)
        table.put_item(Item=event)
        orders_table = ddb.Table('Orders')
        orders_table.put_item(Item=event)
        
    elif action == 'purchased':
        print('item purchased')
        assert event['status'] == 'delivered'
        event.update({'status': 'purchased'})
        print(event)
        table.put_item(Item=event)
        orders_table = ddb.Table('Orders')
        orders_table.put_item(Item=event)
        
    elif action == 'picked up':
        print('item being ordered')
        assert event['status'] == 'delivered'
        event.update({'status': 'ordered'})
        print(event)
        table.put_item(Item=event)
        orders_table = ddb.Table('Orders')
        orders_table.put_item(Item=event)
        print('item ordered')
        
    elif action == 'needs returning':
        print('item needs returning')
        assert event['status'] == 'picked up'
        event.update({'status': action})
        print(event)
        table.put_item(Item=event)
        orders_table = ddb.Table('Orders')
        orders_table.put_item(Item=event)
        
    else:
        raise('No action supplied to update recommendation')
   
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!'),
        'headers': {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": True,
            "Access-Control-Allow-Methods": "*"
        }
    }
