import json
import boto3
#import requests

class DecimalEncoder(json.JSONEncoder):
    def _iterencode(self, o, markers=None):
        if isinstance(o, decimal.Decimal):
            # wanted a simple yield str(o) in the next line,
            # but that would mean a yield on the line with super(...),
            # which wouldn't work (see my comment below), so...
            return (str(o) for o in [o])
        return super(DecimalEncoder, self)._iterencode(o, markers)

def lambda_handler(event, context):
    #requests.post('https://api.segment.io/v1/track', data={'event':'get stylists'})
    
    ddb = boto3.resource('dynamodb')
    table = ddb.Table('Stylists')
    stylists = table.scan()['Items']
    
    return {
        'statusCode': 200,
        'body': json.dumps(stylists, cls=DecimalEncoder)
    }

