import json
import boto3
import decimal

class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            if o % 1 > 0:
                return float(o)
            else:
                return int(o)
        return super(DecimalEncoder, self).default(o)


def lambda_handler(event, context):
    body = event['body']
    body = json.loads(body)
    query = body['search']
    print('query:', query)
    queries = []
    query = query.lower()
    queries.extend(query.split(' '))
    queries.extend([q + 's' for q in queries])
    queries.extend([q[:-1] for q in queries if q[-1] == 's'])
    
    ddb = boto3.resource('dynamodb')
    rev_idx = ddb.Table('ProductReverseIndex')
    
    results = []
    for q in queries:
        print('querying:', q)
        try:
            r = rev_idx.get_item(Key={'key': q})['Item']['products']
            
            print(r)
            print(type(r))
            results.extend(r)
        except:
            print('\tNo results found for ', q)

    print('found results:', results)
    return {
        'statusCode': 200,
        'body': json.dumps(results, cls=DecimalEncoder),    
        'headers': {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": True,
            "Access-Control-Allow-Methods": "*"
        }
    }

