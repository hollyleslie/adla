import json
import boto3
import ast

def lambda_handler(event, context):
    print('initial event:', event)
    userSub = event['context']['sub']
    event = event['body-json']
    print(event)
    print(type(event))
    
    if isinstance(event, str):
        key = event.split('=')[0]
        val = event.split('=')[1]
        event = {key: val} 
   
    user_dir = 'users/' + userSub + '/'         # get user's dir

    s3 = boto3.resource('s3')
    user_info_file = s3.Object('adla-data', user_dir + 'basic_details.json')
    user_info = user_info_file.get()['Body'].read().decode('utf-8')
    user_info = ast.literal_eval(user_info)
    
    print(user_info)
    print(type(user_info))
    
    ### DO SOME LOGGING OF ANY PROFILE UPDATES MADE - TRACK STYLE PREFS OVER TIME
    
    user_info.update(event)
    print(user_info)
    
    user_info_file.put(Body=json.dumps(user_info))

    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }

