import json
import boto3
import pickle
import heapq
import uuid
from decimal import Decimal
import time

def lambda_handler(event, context):
    print('initial event:', event)
    userSub = event['context']['sub']
    
    event = event['body-json']
    print(event)
    
    if 'size' in event.keys():
        event['size'] = {k: v for k, v in event['size'].items() if v is not ''}
        
    # strip whitespace from string values
    for k, v in event.items():
        if isinstance(v, str):
            v = v.strip()
            event[k] = v
            
    if 'instagram' in event.keys():
        event['instagram'] = event['instagram'].lower()
    
    event = {k: v for k, v in event.items() if k in ['gender', 'acq_channel', 'location', 'age', 'instagram', 'price_range', 'referral', 'brands', 'size', 'styles']}
    event = {k: v for k, v in event.items() if v is not ''}
    print('updating entry with:', event)

    ddb = boto3.resource('dynamodb')
    table = ddb.Table('Users')
    body = table.get_item(
        Key={'user_sub': userSub}
    )['Item']
    print('origi entry:', body)
    location_being_set = 'location' not in body.keys() and 'location' in event.keys()
    body.update(event)
    print('final entry:', body)
    table.put_item(Item=body)
    
    # LET USER KNOW IF THEY JUST SAID THAT THEY'RE IN AN AREA WE DONT SERVE
    if location_being_set:
        print('location being set')
        invalid_location_being_set = event['location'] not in ['London', 'San Francisco/Bay Area']
        if invalid_location_being_set:
            print('invalid location being set')
            # UPDATE PRIORITY QUEUE
            s3 = boto3.resource('s3')
            jobs = s3.Object('adla-data', 'jobs.pickle')
            priorities = jobs.get()['Body'].read()
            priorities = pickle.loads(priorities)
            entry = priorities['entry_finder'][userSub]             # get users current entry
            priority, userSub, obj = entry
            priority =  0                                           # zero priority of user in invalid location
            entry = (priority, userSub, obj)
            # no need to check if in priority queue already because user was just created
            heapq.heappush(priorities['priority_queue'], entry)     # add entry to priorities
            priorities['entry_finder'].update({userSub: entry})     # map usersub to that priority entry
            jobs.put(Body=pickle.dumps(priorities))
            
            msg_buffer = ddb.Table('MessageBuffer')
            contact_method = body['contact_method']
            target = body[contact_method]
            msg = {
                'message_id': str(uuid.uuid4()),
                'send_time': Decimal(time.time()) + 2000,  # add index to ensure messages can be ordered
                'user_id': userSub,
                'target': target,
                'contact_method': 'instagram',
                'content': 'Oh nooo! I just realised that you\'re out of where we can serve 😭. Where are you based',
                'type': 'text'
            }
            msg_buffer.put_item(Item=msg)
            

    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!'),
        "headers": { 
            "Access-Control-Allow-Origin": "*" ,
            "Access-Control-Allow-Credentials": True
        }
    }

