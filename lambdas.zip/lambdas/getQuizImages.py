import boto3
import json
s3 = boto3.resource('s3')
my_bucket = s3.Bucket('adla.site')
quiz_dir = "images/quiz"
img_dir = "images/products"

q_id_idx = len(quiz_dir.split('/'))    # how many folders deep are the imgs?

def lambda_handler(event, context):
    
    # READ THE FILE NAMES FROM THE QUIZ FOLDER (THIS FOLDER IS JUST USED TO TELL US THE ID OF THE PIC)
    files = [object_summary.key for object_summary in my_bucket.objects.filter(Prefix=quiz_dir)]
    question_ids = list(set([file.split('/')[q_id_idx] for file in files]))
    
    # ACTUALLY GET THE IMAGE NAMES FROM THE DIR WITH ALL THE IMAGES IN
    quiz_img_dict = {}
    for question_id in question_ids:
        print('Looking for imgs in ', question_id)
        img_ids = [ob_sum.key for ob_sum in my_bucket.objects.filter(Prefix=f'{quiz_dir}/{question_id}/')]
        img_ids = [img_id.split('/')[-1] for img_id in img_ids]
        print(img_ids)
        
        quiz_img_dict[question_id] = [f'{img_dir}/{img_id}' for img_id in img_ids]
        #quiz_img_dict[question_id] = [img for img in quiz_img_dict[question_id] if img[-1] != '/']          # remove the "images/products/" which is also returned
    
    # RETURN THE IMG NAMES
    return {
        'body': json.dumps(quiz_img_dict)
    }
