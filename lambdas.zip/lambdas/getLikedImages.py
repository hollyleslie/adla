import json
import boto3
from boto3.dynamodb.conditions import Key

def lambda_handler(event, context):

    qsParams = event['queryStringParameters']
    print(qsParams)
    user_sub = qsParams['user_sub']
    print(event)

    ddb = boto3.resource('dynamodb')
    table = ddb.Table('Likes')
    liked_imgs = table.query(KeyConditionExpression=Key('user_id').eq(user_sub))['Items']
    liked_imgs = [img for img in liked_imgs if img['response'] == 'yes']

    print(liked_imgs)
    
    return {
        'statusCode': 200,
        'body': json.dumps(liked_imgs),
        "headers": { 
            "Access-Control-Allow-Origin": "*" ,
            "Access-Control-Allow-Credentials": True
        }
    }
