import json
import boto3
import uuid
import time
import datetime
from decimal import Decimal
import heapq
import pickle

def lambda_handler(event, context):
    
    ddb = boto3.resource('dynamodb')
    
    ts = time.time()
    timestamp = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')

    print(event)
    userSub = event['context']['sub']
    print('user sub:', userSub)
    event = event['body-json']
    print(event)
    
    event.update({'instagram': event['instagram'].replace('@', '').lower()})
    print('instagram:', event['instagram'])
    
    name = event['name']
    request_message = [
        {'content': f'Hey {name.split(" ")[0]} it\'s Adla!', 'type': 'text'},
        {'content': 'I\'m busy finding you clothes you\'ll love.', 'type': 'text'},
        {'content': 'Is there anything specific you want me to find for you?', 'type': 'text'},
        {'content': 'You can send me photos of you looking amazing and screenshot any styles you like! They\'ll help me make better recommendations!', 'type': 'text'},
        {'content': 'The more I learn about your style, the better I\'ll get at doing my job!', 'type': 'text'}
    ]
    contact_method = event['contact_method']
    target = event[contact_method]
    msg_table = ddb.Table('MessageBuffer')
    for idx, msg in enumerate(request_message):
        msg.update({
            'message_id': str(uuid.uuid4()),
            'send_time': Decimal(time.time()) + 200 + idx,  # add index to ensure messages can be ordered
            'user_id': userSub,
            'target': target,
            'contact_method': contact_method
        })
        print(msg['send_time'])
        print('adding this msg to message buffer db:', msg)
        msg_table.put_item(Item=msg)
    
    # SAVE USER DETAILS IN USERS DB
    ddb = boto3.resource('dynamodb')
    table = ddb.Table('Users')
    user = {
        'user_sub': userSub,
        'name': event['name'],
        'instagram': event['instagram'].lower(),
        'phone_number': event['phone_number'],
        'location': event['location'],
        'joined': timestamp,
        'acquired_through': event['acq_channel'],
        'gender': event['gender'],
        'password': event['password'],
        'price_range': event['price_range'],
        'referral': event['referral'],
        'contact_method': event['contact_method']
    }
    user = {k: v for k, v in user.items() if v is not ''}
    table.put_item(Item=user)
    
    print('')
    
    if 'referral' in user.keys():
        print('handling referral')
        try:
            body = {
                'type': 'text',
                'send_time': Decimal(time.time()),  # add index to ensure messages can be ordered
                'user_id': 'admin',
                'content': f'ADMIN MESSAGE: New user {userSub} signed up with referral code: {event["referral"]}'
            }
            admins = [
                {'target': '16507094150', 'user_id': 'Harry', 'contact_method': 'phone_number'}, 
                {'target': '16507094147', 'user_id': 'Holly', 'contact_method': 'phone_number'}
            ]
            for d in admins:
                body.update(d)
                body.update({'message_id': str(uuid.uuid4())})
                msg_table.put_item(Item=body)
        except:
            print('INVALID CODE')
            pass
        
    admins = [
        {'target': '16507094150', 'contact_method': 'phone_number', 'user_id': 'Harry', 'contact_method': 'phone_number'}, 
        {'target': '16507094147', 'contact_method': 'phone_number', 'user_id': 'Holly', 'contact_method': 'phone_number'}
    ]
    for d in admins:
        body = {
            'type': 'text',
            'send_time': Decimal(time.time()),  # add index to ensure messages can be ordered
            'content': f'NEW USER: New user {event["name"]}, https://adla.site/5015db37-0d03-4f44-93a5-606ac215935b/admin/user?sub={userSub}'
        }
        body.update(d)
        body.update({'message_id': str(uuid.uuid4())})
        msg_table.put_item(Item=body)
        
    # UPDATE PRIORITY QUEUE
    s3 = boto3.resource('s3')
    obj = s3.Object('adla-data', 'jobs.pickle')
    
    priorities = obj.get()['Body'].read()
    priorities = pickle.loads(priorities)


    priority = 50
    entry = (priority, userSub, user)
    # no need to check if in priority queue already because user was just created
    heapq.heappush(priorities['priority_queue'], entry)     # add entry to priorities
    priorities['entry_finder'].update({userSub: entry})     # map usersub to that priority entry
    k = priorities['entry_finder'][userSub]
    print('key:', k)
    obj.put(Body=pickle.dumps(priorities))

    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }

