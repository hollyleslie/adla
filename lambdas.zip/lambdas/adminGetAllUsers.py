import json
import boto3
import pickle


def lambda_handler(event, context):
    
    # ddb = boto3.resource('dynamodb')
    # user_table = ddb.Table('Users')
    # user_infos = user_table.scan()['Items']
    # print(len(user_infos))
    # print()
    # print('21568fd1-bac1-4d03-9c57-7680486209b5' in [user['user_sub'] for user in user_infos])
    # rec_table = ddb.Table('RecommendationBuffer')
    # recs = rec_table.scan()['Items']
    # unique_users = set([usr['user_id'] for usr in recs])
    # print('unique users:', unique_users)
    # users_served = []
    # for usr_id in unique_users:
    #     num_recs_made = len([rec for rec in recs if rec['user_id'] == usr_id])
    #     if num_recs_made >= 3:
    #         users_served.append(usr_id)
    # print('served users:', users_served)
    #user_infos = [user_info for user_info in user_infos if user_info['user_sub'] not in users_served]
    
    # for u in user_infos:
    #     if 'password' in u.keys():
    #         u.pop('password')
    
    # GET PRIORITY QUEUE
    s3 = boto3.resource('s3')                               # get s3 resource
    obj = s3.Object('adla-data', 'jobs.pickle')               # get jobs
    priorities = obj.get()['Body'].read()                   # decode to string
    priorities = pickle.loads(priorities)                     # load to object
    user_infos = priorities['priority_queue']
    user_infos.sort()
    user_infos = [user[2] for user in user_infos]

    print('ALL USERS:', user_infos)
    return {
        "statusCode": 200,
        "body":  json.dumps(user_infos),
        "headers": { 
            "Access-Control-Allow-Origin": "*" ,
            "Access-Control-Allow-Credentials": True
        }
    }
