import json
import boto3

def lambda_handler(event, context):
    
    print('initial event:', event)
    uploaded_by = event['context']['sub']
    
    event = event['body-json']
    print(event)

    ddb = boto3.resource('dynamodb')
    table = ddb.Table('Products')
    print('Products:', event)
    with table.batch_writer() as batch:
        for product in products:
            batch.put_item(Item=product)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }

