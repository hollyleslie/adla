import json
import boto3
import uuid
import datetime
import time
import ast
from decimal import Decimal
import heapq
import pickle

def is_first_request(user_id):
    s3 = boto3.resource('s3')
    requests = [req for req in s3.Bucket('adla-data').objects.filter(Prefix=f'users/{user_id}/requests')]
    print('all requests', requests)
    if len(requests) > 0:
        return False
    else:
        return True


def lambda_handler(event, context):
    print(event)

    user_id = event['context']['sub']
    
    event = event['body-json']
    print(event)

    print('Sub:', user_id)
   
    request_id = str(uuid.uuid4())
    ts = time.time()
    timestamp = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
   
    # SAVE REQUEST IN REQUEST DB
    print('Saving request in DB')
    ddb = boto3.resource('dynamodb')
    table = ddb.Table('Requests')
    print(event)
    event = {
        'request': event['request'],
        #'budget': event['budget'],
        'user_id': user_id,
        'timestamp': timestamp,
        'served': False,
        'requestID': request_id#,
        # 'name': name
    }
    
    event = {key: item for key, item in event.items() if item is not ''}

    print('request to be put in DB:', event)
    table.put_item(Item=event)
    
    request = {
        'request': event['request'],
        'timestamp': timestamp,
        'served': False
    }
    
    user_table = ddb.Table('Users')
    user = user_table.get_item(Key={'user_sub': user_id})['Item']
    if 'requests' in user.keys():
        reqs = user['requests']
    else:
        reqs = []
    reqs.append(request)
    user.update({'requests': reqs})
    print('USER:', user)
    user_table.put_item(Item=user)
    
    
    msg_table = ddb.Table('MessageBuffer')
    admins = [
        {'target': '16507094150', 'contact_method': 'phone_number', 'user_id': 'Harry'}, 
        {'target': '16507094147', 'contact_method': 'phone_number', 'user_id': 'Holly'}
    ]
    for d in admins:
        body = {
            'type': 'text',
            'send_time': Decimal(time.time()),  # add index to ensure messages can be ordered
            'content': f'NEW REQUEST: \n {event["request"]} \n\ https://adla.site/5015db37-0d03-4f44-93a5-606ac215935b/admin/user?sub={user_id}'
        }
        body.update(d)
        body.update({'message_id': str(uuid.uuid4())})
        msg_table.put_item(Item=body)
        
    stylist_table = ddb.Table('Stylists')
    stylists = stylist_table.scan()['Items']
    #stylists = [stylist for stylist in stylists if stylist['stylist_id'] == '5663ea02-693f-4111-b1a6-c035420ca7aa']
    msg = {
        'type': 'text',
        'message_id': str(uuid.uuid4()),
        'content': 'Hey! There\'s a new user to serve! Check it out here! : https://adla.site/9j3d7w31-lfvl-98je-wewf-p1sbdhjcs636/stylist/all_users',
        'send_time': Decimal(time.time())
    }
    # for stylist in stylists:
    #     contact_method = stylist['contact_method']
    #     target = stylist[contact_method]
    #     msg.update({
    #         'contact_method': contact_method,
    #         'target': target,
    #         'user_id': stylist['stylist_id']
    #     })
    #     # msg_table.put_item(Item=msg)
        
    # UPDATE PRIORITY QUEUE
    s3 = boto3.resource('s3')                               # get s3 resource
    obj = s3.Object('adla-data', 'jobs.pickle')               # get jobs
    priorities = obj.get()['Body'].read()                   # decode to string
    priorities = pickle.loads(priorities)                     # load to object
    entry = priorities['entry_finder'][user_id]             # get users current entry
    priority, _user_id, _obj = entry                        # unpack current entry
    priority += 50                                          # boost priority
    if user['location'] not in ['London', 'San Francisco/Bay Area']:
        print('user not in valid service ')
        priority = 0
    print('users new priority:', priority)
    new_entry = (priority, user_id, user)                   # update entry
    heapq.heappush(priorities['priority_queue'], new_entry) # heap push new entry
    priorities['priority_queue'].remove(entry)              # remove old entry
    priorities['entry_finder'][user_id] = new_entry         # update entry finder
    obj.put(Body=pickle.dumps(priorities))                                # save updated jobs
  

    print('All done')
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
