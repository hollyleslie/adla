import json
import boto3
import uuid
import time
from decimal import Decimal

def lambda_handler(event, context):
    print('INITIAL EVENT:', event)

    pathParams = event['queryStringParameters']
    print('path parameters', pathParams)
    user_id = pathParams['user_id']
    event = json.loads(event['body'])

    ddb = boto3.resource('dynamodb')
    user_table = ddb.Table('Users')
    user = user_table.get_item(Key={'user_sub': user_id})['Item']
    phone_number = user['phone_number']
    
    msg_table = ddb.Table('MessageBuffer')
    item = {
        'message_id': str(uuid.uuid4()),
        'content': event['body'],
        'target': phone_number,
        'type': event['type'],
        'send_time': Decimal(time.time()),
        'user_id': user_id,
        'contact_method': 'phone_number'
    }
    if event['type'] == 'file':
        item.update({'media_url': event['media_url']})
    msg_table.put_item(Item=item)

    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!'),
        "headers": { 
            "Access-Control-Allow-Origin": "*" ,
            "Access-Control-Allow-Credentials": True
        }
    }

