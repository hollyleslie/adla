import json
import boto3
import ast

def lambda_handler(event, context):

    print('initial event:', event)
    user_id = event['context']['sub']
    print(user_id)
    event = event['body-json']
    print(event)
    
    ddb = boto3.resource('dynamodb')
    table = ddb.Table('Users')
    user_info = table.get_item(Key={'user_sub': user_id})['Item']
    if 'password' in user_info.keys():
        user_info.pop('password')
        
    return {
        "statusCode": 200,
        "body":  json.dumps(user_info),
        "headers": { 
            "Access-Control-Allow-Origin": "*" ,
            "Access-Control-Allow-Credentials": True
        }
    }
