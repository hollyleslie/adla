import json
import boto3

def lambda_handler(event, context):

    ddb = boto3.resource('dynamodb')
    
    stylist_id = event['stylist_id']
    user_id = event['user_id']

    # ASSIGN USER TO STYLIST
    stylist_table = ddb.Table('Stylists')
    stylist = stylist_table.get_item(Key={'stylist_id': stylist_id})['Item']
    
    if 'clients' not in stylist.keys():
        stylist.update({'clients': []})
        
    clients = stylist['clients']
    if user_id in clients:
        clients.remove(user_id)
    else:
        clients.append(user_id)
    
    stylist.update({'clients': clients})
    print(stylist)
    stylist_table.put_item(Item=stylist)
    
    
    # ASSIGN STYLIST TO USER
    user_table = ddb.Table('Users')
    client = user_table.get_item(Key={'user_sub': user_id})['Item']
    
    if 'assigned_to' not in list(client.keys()):
        client.update({'assigned_to': []})
    assigned_to = client['assigned_to']
    
    # TOGGLE ASSIGNMENT TO THIS USER
    if stylist_id in assigned_to:               # unassign
        assigned_to.remove(stylist_id)
    else:
        assigned_to.append(stylist_id)          # assign
    
    client.update({'assigned_to': assigned_to})
    user_table.put_item(Item=client)

    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }

