import json
import boto3

def lambda_handler(event, context):

    print('og event:', event)
    
    userSub = event['context']['sub']
    print('Sub:', userSub)

    event = event['body-json']
    item = event
    item['userSub'] = userSub
    
    ddb = boto3.resource('dynamodb')    
    table = ddb.Table('UserBrandLikes')
    table.put_item(Item=item)
    #io

    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }

