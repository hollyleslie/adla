import json
import boto3
import uuid
import time
import datetime

def lambda_handler(event, context):

    print('initial event:', event)
    
    ts = time.time()
    timestamp = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')

    # GET RECOMMENDATION DETAILS
    pathParams = event['queryStringParameters']
    print('path parameters', pathParams)
    req_id = pathParams['req_id']
    userSub = pathParams['sub']
    
    recommendation = json.loads(event['body'])
    
    # POST RECOMMENDATION TO DDB
    ddb = boto3.resource('dynamodb')
    table = ddb.Table('Recommendations')
    recommendation.update({
        'Request ID': req_id,
        'Item ID': str(uuid.uuid4()),
        'userSub': userSub,
        'timestamp': timestamp
    })
    print('recommendation:', recommendation)
    table.put_item(Item=recommendation)
   
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!'),
        'headers': {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": True,
            "Access-Control-Allow-Methods": "*"
        }
    }
