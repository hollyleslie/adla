import json
import boto3
import ast

def lambda_handler(event, context):

    userSub = event['context']['sub']
    print(userSub)
    user_dir = 'users/' + userSub + '/'

    s3 = boto3.resource('s3')
    file = user_dir + 'styleboards.json'
    print(file)
    
    file = s3.Object('adla-data', file)
    try:
        file = file.get()['Body'].read().decode('utf-8')
        file = ast.literal_eval(file)
    except Exception as e:
        print('Error:', e)
        file = []    
    print(file)

    print('imgs to return', file)
    if len(file) == 0:
        print('no styleboard imgs yet')
        file = None
    return {
        'statusCode': 200,
        'body': json.dumps(file),
        "headers": { 
            "Access-Control-Allow-Origin": "*" ,
            "Access-Control-Allow-Credentials": True
        }
    }

