import json
import boto3
import uuid
import time
from datetime import datetime
from botocore.exceptions import ClientError
from decimal import Decimal

def lambda_handler(event, context):
    
    print(event)

    try:
        
        username = event['name'] + '.stylist'
        temp_password = event['name'] + '12345'
        client = boto3.client('cognito-idp', region_name='eu-west-2')
        c = client.admin_create_user(
            UserPoolId='eu-west-2_x5atHpPTt',
            Username=username,
            TemporaryPassword=temp_password
        )
        
        stylist_attrs = c['User']['Attributes']
        stylist_attrs = {a['Name']: a['Value'] for a in stylist_attrs}
        print('stylist attrs:', stylist_attrs)
        stylist_id = stylist_attrs['sub']
        
        client.admin_add_user_to_group(
            UserPoolId='eu-west-2_x5atHpPTt',
            Username=username,
            GroupName='stylists'
        )
        print('stylist:', c)
        
    
        print(event['instagram'])
        stylist = {
            'name': event['name'],
            'stylist_id': stylist_id,
            'code': event['code'],
            'added': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'instagram': event['instagram'],
            'location': event['location'],
            'call_time': event['call_time']
        }
        
        stylist = {k: v for k, v in stylist.items() if v != ''}
        
        ddb = boto3.resource('dynamodb')
        
        table = ddb.Table('Stylists')
        table.put_item(Item=stylist)
        
        msg_buffer = ddb.Table('StylistMessageBuffer')
        template = {
            'target': event['instagram'], 
            'contact_method': 'instagram',
            'category': 'general',
            'stylist_id': stylist_id,
            'type': 'text'
        }
        msgs = [
            f'Hi {event["name"]}',
            'Log in to the styling app here:', 
            'https://adla.site/9j3d7w31-lfvl-98je-wewf-p1sbdhjcs636/stylist',
            f'Username: {username}',
            f'Temporary password: {temp_password}'
        ]
        for msg in msgs:
            template.update({
                'content': msg,
                'message_id': str(uuid.uuid4()),
                'send_time': Decimal(time.time())
            })
            msg_buffer.put_item(Item=template)
        
        return {
            'statusCode': 200,
            'body': json.dumps('Success'),
            "headers": { 
                "Access-Control-Allow-Origin": "*" ,
                "Access-Control-Allow-Credentials": True
            }
        }
        
    except ClientError as e:
        print("Unexpected error: %s" % e)
        print('returning error')
        raise ValueError('failed')

