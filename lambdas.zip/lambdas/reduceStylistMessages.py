import json
import boto3
import uuid
import time
from decimal import Decimal

def check_if_trial(item):
    if item['category']=='item trial':
        return True
    else:
        return False

def lambda_handler(event, context):
    # TODO implement
    
    ddb = boto3.resource('dynamodb')
    stylist_message_table = ddb.Table('StylistMessageBuffer')
    
    items = stylist_message_table.scan()['Items']
    trial_items = list(filter(check_if_trial, items))
    
    unique_stylist_ids = []
    for item in items:
        if item['stylist_id'] not in unique_stylist_ids:
            unique_stylist_ids.append(item['stylist_id'])
    for unique_stylist_id in unique_stylist_ids:
        def check_if_stylists_item(item):
            if item['stylist_id']==unique_stylist_id:
                return True
            else:
                return False
        unique_stylist_trial_items = list(filter(check_if_stylists_item, trial_items))
        n_item_trials = len(unique_stylist_trial_items)
        if n_item_trials<1:
            continue
        
        body = {
            'message_id':str(uuid.uuid4()),
            'contact_method':unique_stylist_trial_items[0]['contact_method'],
            'target':unique_stylist_trial_items[0]['target'],
            'send_time':Decimal(time.time()),
            'type':'text',
            'stylist_id':unique_stylist_id,
            'content':'Congrats! Someone wants to try on '+str(n_item_trials)+' of your recommendations!',
            'category':'item trial reduced'
        }
        stylist_message_table.put_item(Item=body)
        
        for item in unique_stylist_trial_items:
            stylist_message_table.delete_item(
                Key={
                    'message_id': item['message_id'],
                }
            )
    
    return {
        'statusCode': 200,
        'body': json.dumps('Great success!')
    }

