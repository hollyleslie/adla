import json
import boto3

def lambda_handler(event, context):
    print(event)
    
    qsParams = event['queryStringParameters']
    print(qsParams)
    req_id = qsParams['req_id']

    ddb = boto3.resource('dynamodb')
    table = ddb.Table('Requests')
    
    print('initial event:', event)

    req = table.get_item(
        Key={
            'requestID': req_id
        }    
    )['Item']
    
    print('request:', req)
    
    return {
        'statusCode': 200,
        'body': json.dumps(req),
        'headers': { 
            "Access-Control-Allow-Origin": "*" ,
            "Access-Control-Allow-Credentials": True
        }
    }

