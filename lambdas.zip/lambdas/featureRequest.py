import json
import boto3
import time
import uuid
from decimal import Decimal

def lambda_handler(event, context):
    
    user_id = event['requestContext']['authorizer']['claims']['sub']
    print('initial event:', event)
    event = json.loads(event['body'])
    print('event body:', )
    s3 = boto3.resource('s3')
    
    if event['type'] == 'new brand request':
        key = 'brand_requests.json'
    elif event['type'] == 'new feature request':
        key = 'feature_requests.json'
    elif event['type'] == 'new tag request':
        key = 'tag_requests.json'
    obj = s3.Object('adla-data', key)
    try:
        requests = json.loads(obj.get()['Body'].read().decode('utf-8'))
    except:
        requests = []
    requests.append({'request': event['request'], 'requested_by': user_id})
    obj.put(Body=json.dumps(requests))
    
    ddb = boto3.resource('dynamodb')
    msg_table = ddb.Table('MessageBuffer')
    msg = {
        'content': f'{event["type"]}: {event["request"]}',
        'target': '16507094150',
        'contact_method': 'phone_number',
        'message_id': str(uuid.uuid4()),
        'type': 'text',
        'user_id': 'Harry',
        'send_time': Decimal(time.time())  # add index to ensure messages can be ordered
    }
    msg_table.put_item(Item=msg)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Success!'),
        'headers': {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": True,
            "Access-Control-Allow-Methods": "*"
        }
    }

