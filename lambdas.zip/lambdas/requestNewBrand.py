import json
import boto3
import time
import uuid
from decimal import Decimal

def lambda_handler(event, context):
    
    user_id = event['requestContext']['authorizer']['claims']['sub']
    event = json.loads(event['body'])
    s3 = boto3.resource('s3')
    obj = s3.Object('adla-data', 'brand_requests.json')
    try:
        brands = json.loads(obj.get()['Body'].read().decode('utf-8'))
    except:
        brands = []
        
    brands.append({'brand': event, 'requested_by': user_id})
    obj.put(Body=json.dumps(brands))
    
    ddb = boto3.resource('dynamodb')
    msg_table = ddb.Table('MessageBuffer')
    msg = {
        'content': f'NEW brand requested: {event}',
        'target': '16507094150',
        'contact_method': 'phone_number',
        'message_id': str(uuid.uuid4()),
        'type': 'text',
        'user_id': 'Harry',
        'send_time': Decimal(time.time())  # add index to ensure messages can be ordered
    }
    msg_table.put_item(Item=msg)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Brand requested!'),
        'headers': {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": True,
            "Access-Control-Allow-Methods": "*"
        }
    }

