import json
import boto3
from boto3.dynamodb.conditions import Key
import decimal

class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, decimal.Decimal):
            if o % 1 > 0:
                return float(o)
            else:
                return int(o)
        return super(DecimalEncoder, self).default(o)

def lambda_handler(event, context):

    print('initial event:', event)
    
    # GET RECOMMENDATION DETAILS
    pathParams = event['queryStringParameters']
    print('path parameters', pathParams)
    
    # IF FROM A REQUEST THEN USE THAT REQUEST ID TO RETURN THE RECS (GSI FOR DB)
    if 'req_id' in pathParams:
        val = pathParams['req_id']
        key = {
            'IndexName': 'request_id-recommendation_id-index',
            'KeyConditionExpression': Key('request_id').eq(val)
        }
    # OTHERWISE USE THE USER ID 
    else:
        val = pathParams['user_id']
        key =  {
            'KeyConditionExpression': Key('user_id').eq(val)
        }

    # get RECOMMENDATION TO DDB
    ddb = boto3.resource('dynamodb')
    table = ddb.Table('Recommendations')
    recommendations = table.query(**key)['Items']
    print(recommendations)
            
    print('recommendations:', recommendations)
   
    return {
        'statusCode': 200,
        'body': json.dumps(recommendations, cls=DecimalEncoder),
        "headers": { 
            "Access-Control-Allow-Origin": "*" ,
            "Access-Control-Allow-Credentials": True
        }
    }
