import json
import boto3
from boto3.dynamodb.conditions import Key
import time
import datetime

def lambda_handler(event, context):

    print('initial event:', event)
    
    ts = time.time()
    timestamp = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')

    # GET ORDER
    print(event)
    pathParams = event['params']['querystring']
    print('path parameters', pathParams)
    req_id = pathParams['req_id']
    userSub = pathParams['sub']

    user_dir = 'users/' + userSub + '/'

    s3 = boto3.resource('s3')
    order_fp = user_dir + 'requests/' + req_id + '.json'
    order_file = s3.Object('adla-data', order_fp)
    order = order_file.get()['Body'].read().decode('utf-8')
    order = json.loads(order)
    print('order:', order)
    print('order type:', type(order))
    
    ddb = boto3.resource('dynamodb')
    table = ddb.Table('Recommendations')
    
    # get all recommendations for this order (may or may not have been recommended already)
    recs = table.query(
        KeyConditionExpression=Key('Request ID').eq(req_id)
    )['Items']
    print('recs:', recs)

    event = event['body-json']
    nextStatus = event['nextStatus']
    
    # UPDATE REQUEST
    if (nextStatus == 'recommendations_made'):
        print('Recommending items')
        
        # filter potential recommendations to get those that haven't already been recommended
        new_recs = [rec for rec in recs if rec['status'] == 'not yet recommended']
        new_recs = [{**rec, 'status': 'recommended'} for rec in new_recs]   # change status of each item from 'not yet recommended' to 'recommended'
        print('recs to actually recommended:', new_recs)
        
        if len(new_recs) > 0:   # otherwise empty recommendation list and timestamp, type will still be appended to timeline
            print('order:', order)
            order.append(
                {
                    'type': 'recommendations',
                    'content': new_recs,
                    'timestamp': timestamp
                }    
            )
            print('updated order:', order)
            print('number of total timeline stages:', len(order))
            print('All recs to put back in db:', new_recs)
            
            # PUT ORDER BACK IN S3
            order_file.put(Body=json.dumps(order))
            
            # PUT EACH ENTRY BACK INTO RECOMMENDATIONS 
            for rec in new_recs:
                print('Putting back:', )
                table.put_item(Item=rec)    # put items back into database after status changed to 'recommended'
        else:
            print('No unserved recommendations to add')


    return {
        'statusCode': 200,
        'body': json.dumps('order status updated')
    }

